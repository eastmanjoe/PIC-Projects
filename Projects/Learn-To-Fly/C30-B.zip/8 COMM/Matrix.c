/*
**  The Matrix
**
*/
#include <p24fj128ga010.h>

#include "CONU2.h"
#include <stdlib.h>

#define COL     40
#define ROW     23
#define DELAY 3000

main()
{
    int v[40];  // vector containing lengh of each string
    int i,j,k;
    
    // 1. initializations
    T1CON = 0x8030; // TMR1 on, prescale 256, Tcy/2
    initU2();   // initialize the console (115200, 8, N, 1, CTS/RTS)
    clrscr();   // clear the terminal (VT100 emulation)
    getU2();    // wait for one character to randomize the sequence
    srand( TMR1); 
    
    // 2. init each column lenght
    for( j =0; j<COL; j++)
            v[j] = rand()%ROW;
    
    // 3. main loop
    while( 1)
    {
        home();
        
        // 3.1 refresh the screen with random columns
        for( i=0; i<ROW; i++)
        {
            // 3.1.1 delay to slow down the screen update
            TMR1 =0;   
            while( TMR1<DELAY);
            
            // refresh one row at a time
            for( j=0; j<COL; j++)
            {
                // print a random character down to each column lenght
                if ( i < v[j])
                    putU2( 33 + (rand()%94));
                else 
                    putU2(' ');
                putU2( ' ');
            } // for j
            pcr();
            
        } // for i

        // 3.2 randomly increase or reduce each column lenght
        for( j=0; j<COL; j++)
        {
            switch ( rand()%3)
            {
                case 0: // increase length
                        v[j]++;
                        if (v[j]>ROW)
                            v[j]=ROW;
                        break;
                        
                case 1: // decrease length
                        v[j]--;
                        if (v[j]<1)
                            v[j]=1;
                        break;
                        
                default:// unchanged 
                        break;
             } // switch
        } // for


        
    } // main loop
} // main
