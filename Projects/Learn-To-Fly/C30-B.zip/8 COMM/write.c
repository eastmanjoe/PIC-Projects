/*
** write.c
** replaces stdio lib write function
**
*/

#include <p24fj128ga010.h>
#include <stdio.h>
#include "conu2.h"

int write(int handle, void *buffer, unsigned int len)
{
    int i, *p;
    const char *pf;

	switch (handle)
	{
	case 0:
	case 1:
	case 2: // stdout
		for (i = len; i; --i)
            putU2( *(char*)buffer);
		break;
	default:
		break;
	}
	return(len);
}

