/*
** SD card interface 
** 
**
*/

#define FALSE   0
#define TRUE    !FALSE
#define FAIL    0

// IO definitions
#define SD_LED                      _RA0
#define READ_LED                    _RA1
#define WRITE_LED                   _RA2


typedef unsigned long LBA;      // logic block address, 32 bit wide


void initSD( void);     // initializes the I/O pins for the SD/MMC interface 
int initMedia( void);   // initializes the SD/MMC memory device

int detectSD( void);    // detects the card presence 
int detectWP( void);    // detects the position of the write protect switch

int readSECTOR ( LBA, char *);  // reads a block of data 
int writeSECTOR( LBA, char *);  // writes a block of data

