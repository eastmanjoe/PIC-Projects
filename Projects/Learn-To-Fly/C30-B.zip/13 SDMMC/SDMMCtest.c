/*
**	SDMMC read/write Test
**
*/

#include <p24fj128ga010.h>
#include <string.h>

#include "SDMMC.h"

void Delayms( unsigned t)
{
    T1CON = 0x8000;     // enable tmr1, Tcy, 1:1
    while (t--)
    {
        TMR1 = 0;
        while (TMR1<16000);
    }
} // Delayms


#define START_ADDRESS       10000   // start block address
#define N_BLOCKS            10000   // number of blocks
#define B_SIZE              512     // sector/data block size

char    data[ B_SIZE];
char  buffer[ B_SIZE];

main( void)
{
    LBA addr;
    int i, r;

    // I/O initializations
    TRISA = 0xff00;		    // initialize PORTA LEDs output pins
    initSD();			    // initialize all I/Os required for the SD/MMC module

    // fill the buffer with "data"
    for( i=0; i<B_SIZE; i++)
        data[i]= i;
 
    // wait for card to be inserted
    while( !detectSD());    // assumes SDCD pin is by default an input
    Delayms( 100);          // wait for card contacts de-bounce and power up
        
    // initialize the memory card (returns 0 if successful)
    r = initMedia();
    if ( r)                 // could not initialize the card
    {
        PORTA = r;          // show error code on LEDs
        while( 1);          // halt here
    }
    else
    {
        // fill N_BLOCK blocks/SECOTR with the contents of data buffer
        addr = START_ADDRESS;
        for( i=0; i<N_BLOCKS; i++)
            if (!writeSECTOR( addr+i, data))
            {   // writing failed
                PORTA = 0x0f;
                while( 1);  // halt here
            }

        // verify the contents of each block/SECTOR written
        addr = START_ADDRESS;
        for( i=0; i<N_BLOCKS; i++)
        {   // read back one block at a time
            if (!readSECTOR( addr+i, buffer))
            {   // reading failed
                PORTA = 0xf0;
                while( 1);  // halt here
            }
            
            // verify each block content
            if ( !memcmp( data, buffer, B_SIZE))
            {   // mismatch
                PORTA = 0x55;
                while( 1); // halt here
            }
        } // for each block
    } // else media initialized

    // indicate successful execution
    PORTA = 0xFF;
    // main loop
    while( 1);

} // main

