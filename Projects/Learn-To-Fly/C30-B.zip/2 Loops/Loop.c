//
// A Loop in the pattern
//
//

#include <p24fj128ga010.h>
#define DELAY	16

main()
{
	TRISA = 0xff00;	// all PORTA as output
	T1CON = 0x8030; // TMR1 on, prescale 1:256 Tclk/2
	
	while( 1)
	{
		//1.
		PORTA = 0xff;	
		TMR1 = 0;
		while ( TMR1 < DELAY)
		{
		}

		// 2.
		PORTA = 0;
		TMR1 = 0;
		while ( TMR1 < DELAY)
		{
		}
	} // main loop
} // main
