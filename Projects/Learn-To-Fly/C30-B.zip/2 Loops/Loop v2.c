//
// A loop in the pattern
//
// 
//

#include <p24fj128ga010.h>
#define SHORT_DELAY 5
#define LONG_DELAY	80


char font[30] = { 
	0b11111111,	// H
	0b00001000,
	0b00001000,
	0b11111111,
	0b00000000,
	0b00000000,
	0b11111111,	// E
	0b10001001,
	0b10001001,
	0b10000001,
	0b00000000,
	0b00000000,
	0b11111111,	// L
	0b10000000,
	0b10000000,
	0b10000000,
	0b00000000,
	0b00000000,
	0b11111111,	// L
	0b10000000,
	0b10000000,
	0b10000000,
	0b00000000,
	0b00000000,
	0b01111110,	// O
	0b10000001,
	0b10000001,
	0b01111110,
	0b00000000,
	0b00000000
	};
	
main()
{
	int i;
	
	// 0. 
	TRISB = 	0;		// all PORTB as output
	AD1PCFG = 0xffff;	// all PORTB as digital
	T1CON =   0x8030;   // TMR1 on, prescale 1:256 Tclk/2
	
	// 1.  	
	while( 1)
	{
		for( i=0; i<30; i++)
		{
			PORTB = font[i];
				
			//1.1 
			TMR1 = 		0;
			while ( TMR1 < SHORT_DELAY)
			{
			}
		} // for i
			
		// 1.2 
		PORTB = 0;
		TMR1 = 		0;
		while ( TMR1 < LONG_DELAY)
		{
		}
	} // main loop
} // main
