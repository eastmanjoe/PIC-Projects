/*
**   WaveTest
**
*/

#include <p24fj128ga010.h>
#include "../13 sdmmc/SDMMC.h"
#include "../14 fileio/fileio.h"
#include "../buttons/buttons.h"
#include "../Audio/Audio PWM.h"
#include "Wave.h"


int main( void)
{
    TRISA = 0xff00;
 
    if ( !mount())
        PORTA = FError + 0x80;
    else
    {
            PORTA = 0xFF;
        if ( playWAV( "NELLY.WAV"))
            PORTA = 0x1;
    } // mounted

    while( 1)
    {
    } // main loop

} //main 
