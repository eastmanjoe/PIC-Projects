/*
** Audio PWM Test
** sqare and triangular wave 1kHz
**
** LDJ 7/22/06 v1.0
*/

#include <p24fj128ga010.h>

int count;

void initAudio( long bitrate)
{
    // init the timebase
    T3CON = 0x8000;         // enable TMR3, prescale 1:1, internal clock
    PR3 = 400-1;            // set the period for the given bitrate
    _T3IF = 0;              // clear interrupt flag
    _T3IE = 1;              // enable TMR3 interrupt

    // init PWM
    // set the initial duty cycles
    OC1R = OC1RS = 200;  

    // activate the PWM modules 
    OC1CON = 0x000E;        // CH1 and CH2 in PWM mode, TMR3 based

} // initAudio



void _ISRFAST _T3Interrupt( void)
{
    OC1RS = (count < 20) 400 : 0;
    // OC1RS = (count < 20) count*10 : 0; 
    count++;
    if ( count >= 40)
        count = 0;
 
    // clear interrupt flag and exit
    _T3IF = 0;
} // T3 Interrupt


main( void)
{
    initAudio();
    
    // main loop
    while( 1);

}// main

