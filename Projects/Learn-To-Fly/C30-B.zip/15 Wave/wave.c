/*----------------------------------------------------------------------
** Wave.C
** 
** 	Wave File Player 
**	Uses 2 x 8 bit PWM channels at 44kHz
**
*/
#include <stdlib.h>
#include "wave.h"
#include "../Buttons/Buttons.h"
#include "../Audio/Audio PWM.h"
#include "../13 sdmmc/sdmmc.h"
#include "../14 fileio/fileio.h"

// WAVE file constants
#define  RIFF_DWORD  0x46464952UL
#define  WAVE_DWORD  0x45564157UL
#define  DATA_DWORD  0x61746164UL
#define  FMT_DWORD   0x20746d66UL     
#define  WAV_DWORD   0x00564157UL

typedef struct {
    // data chunk
    unsigned long dlength;  // actual data size
    char    data[4];        // "data"

    // format chunk
    unsigned    bitpsample; //
    unsigned    bpsample;   // bytes per sample (4 = 16 bit stereo)
    unsigned long bps;      // bytes per second
    unsigned long srate;    // sample rate in Hz
    unsigned    channels;   // number of channels (1= mono, 2= stereo)
    unsigned    subtype;    // always 01
    unsigned long flength;  // size of encapsulated block (16)
    char    fmt_[4];        // "fmt_"

    char    type[4];        // file type name "WAVE"
    unsigned long tlength;  // size of encapsulated block
    char    riff[4];        // envelope "RIFF"
} WAVE; 


      

unsigned playWAV( const char *name)
{
    int     last;
    WAVE    wav;
    MFILE    *f;
    unsigned wi;
    unsigned long lc, r, d;
    int     skip, size, stereo, fix, pos;
    
    // 1. open the file           
    if ( (f = fopenM( name, "r")) == NULL)
    {   // failed to open 
        return FALSE;
    }
    
    // 2. verify it is a RIFF formatted file
    if ( ReadL( f->buffer, 0) != RIFF_DWORD)
    {
        fcloseM( f);
        return FALSE;
    }
    //putrs( "RIFF file\r");
    
    // 3. look for the WAVE chunk signature 
    if ( (d = ReadL( f->buffer, 8)) != WAVE_DWORD)
    {
        fcloseM( f);
        return FALSE;
    }
    //putrs( "WAVE type chunk found\r");
    
    // 4. look for the chunk containing the wave format data
    if ( ReadL( f->buffer, 12) != FMT_DWORD)
    {
        fcloseM( f);
        return FALSE;
    }
    //putrs( "Format chunk contains:\r");
    
    wav.channels    = ReadW( f->buffer, 22);
    wav.bitpsample  = ReadW( f->buffer, 34);
    wav.srate       = ReadL( f->buffer, 24);
    wav.bps         = ReadL( f->buffer, 28);
    wav.bpsample    = ReadW( f->buffer, 32);
    
    //printb( "Channels        = ", wav.channels); pcr();                        
    //printi( "Bits per Sample = ", wav.bitpsample); pcr();                        
    //printl( "Sample Rate     = ", wav.srate); pcr();                        
    //printl( "Bytes per Second= ", wav.bps); pcr();                        
    //printi( "Bytes per Sample= ", wav.bpsample); pcr();                        

    // 5. search for the data chunk
    wi = 20 + ReadW( f->buffer, 16);  
    while ( wi < 512)
    {
        if (ReadL( f->buffer, wi) == DATA_DWORD)
            break;
        wi += 8 + ReadW( f->buffer, wi+4);
    }
    if ( wi >= 512) // could not find a data chunk in current sector
    {
        //putrs( " DATA chunk not found in first sector!\r");
        fcloseM( f);
        return FALSE;
    }   
    //printxi( "DATA chunk found at offset: 0x", wi+8); pcr();

    // 5.1 find the data size (actual wave content)
    wav.dlength = ReadL( f->buffer, wi+4);
    
    // 6. compute the period and adjust the bit rate
    //printl( "Data size       = ", wav.dlength); pcr();
    r = wav.bps / wav.bpsample;    // r = samples per second
    skip = wav.bpsample;           // skip factor to reduce bandwith (stereo)
    while ( r > 45000)
    {
        r >>= 1;                   // as you divide sample rate by two
        skip <<= 1;                // multiply skip by two
    }
    //printl( "Playing at = ", (dword)r); putrs( " samples per second\r");

    // 6.1 check if the sample rate is compatible with the TMR3 prescaler
    d = (16000000L/r)-1;
    if ( d > ( 65536L))             // max TMR3 period value (16 bit)
    {
        //printi("Too long period = ", rate); pcr();
        fcloseM( f);
        return FALSE;
    }
    //printi( "TMR2 period= ", d); pcr();

    // 7. init the Audio state machine
    CurBuf = 0;
    stereo = (wav.channels == 2);
    //cPlay = (512 -wi -8)/ sPlay;  // number of samples in first sector
    pos   = wi+8;                   // data begin 
    size  = 1;                      // default, number of bytes per channel
    fix   = 0;                      // sign fix / 16 bit file
    if ( wav.bitpsample == 16)
    {
        pos++;                      // add 1 to get the msb
        size = 2;
        fix  = 0x80;
    }
    // nPlay = 512 / sPlay;            // compute the number of samples per sector to play       
    
    // 8. start loading the buffers
    // compute lba of first sector 
    //l = dsk->data + (dword)(f.ccls-2) * dsk->sxc;
    // determine the number of bytes to composing the wav data chunk
    lc = wav.dlength;
    
    // 9. pre-load both buffer
    r = freadM( ABuffer[0], B_SIZE*2, f);
    AEmptyFlag = FALSE;
    lc-= B_SIZE*2 ;                    // we assume here that lc>=B_SIZE*2!!!
        

    // 9. start playing, enable the interrupt 
    initAudio( wav.srate, skip, size, stereo, fix, pos);
    
    //putrs( "Playing now...\r");
    //CTS_USART1 = 0;                 // hardware handshake open 

    // 10. keep feeding the buffers in the playing loop
    while (lc >=B_SIZE)
    {
        if (readKEY())              // on pressing any key
        {                           
            lc = 0;                 // signal playback completed
            break;
        }
        if ( AEmptyFlag)
        {
            r = freadM( ABuffer[1-CurBuf], B_SIZE, f);
            AEmptyFlag = FALSE;
            lc-= B_SIZE;
            
        }
    } // while wav data available

    // 11. flush the buffers with the data tail
    if( lc>0) 
    {
        // load the last sector 
        r = freadM( ABuffer[1-CurBuf], lc, f);
        last = ABuffer[1-CurBuf][r-1];
        while(( r<B_SIZE) && (last>0)) 
            ABuffer[1-CurBuf][r++] = last;
        
        // wait for current buffer to be emptied
        AEmptyFlag = 0;
        while (!AEmptyFlag);
    }

    // 12.finish the last buffer
    AEmptyFlag = 0;
    while (!AEmptyFlag);
    
    // 13. stop playback 
    haltAudio();

    // 14. close the file 
    fcloseM( f);

    // 15. return with success
    return TRUE;

} // playWAV
         


