/*
** Audio PWM Test
** 400Hz sinusoid precomputed @40kHz
**
*/

#include <p24fj128ga010.h>


// local definitions
int Table[];
int Sample;            // pointer inside active buffer

void initAudio( void)
{
    Sample = 0;
    // init the timebase
    T3CON = 0x8000;         // enable TMR3, prescale 1:1, internal clock
    PR3 = 400-1;            // set the period for the given bitrate
    _T3IF = 0;              // clear interrupt flag
    _T3IE = 1;              // enable TMR3 interrupt

    // init PWM
    // set the initial duty cycles
    OC1R = OC1RS = 200;  // left

    // activate the PWM modules 
    OC1CON = 0x000E;        // CH1 and CH2 in PWM mode, TMR3 based

} // initAudio



void _ISRFAST _T3Interrupt( void)
{
    // load the new samples for the next cycle

    // 172Hz sqare wave 
    //OC1RS = (Sample++ > 128) ? 255 : 0;

// 172 Hz sinusoid @44100
    OC1RS = Table[ Sample++]; 
//    OC1RS = 200+ (int)( 200* sin(Sample++ *0.0628));

    Sample = (Sample>=100) ? 0 : Sample;

    // clear interrupt flag and exit
    _T3IF = 0;
} // T3 Interrupt


main( void)
{
    initAudio();
    
    // main loop
    while( 1);

}// main

int Table[100] = {
200,
212,
225,
237,
249,
261,
273,
285,
296,
307,
317,
327,
336,
345,
354,
361,
368,
375,
380,
385,
390,
393,
396,
398,
399,
399,
399,
398,
396,
393,
390,
386,
381,
375,
368,
361,
354,
345,
337,
327,
317,
307,
296,
285,
273,
262,
250,
237,
225,
212,
200,
187,
175,
162,
150,
138,
126,
115,
103,
93,
82,
72,
63,
54,
46,
38,
31,
24,
19,
14,
9,
6,
3,
1,
0,
0,
0,
1,
3,
6,
9,
13,
18,
24,
30,
37,
45,
53,
62,
72,
81,
92,
103,
114,
125,
137,
149,
161,
174,
186,
};
