/*----------------------------------------------------------------------
** Wave.H
** 
** 	Wave File Player 
**	Uses 2 x 8 bit PWM channels at 44kHz
**
*/

unsigned playWAV( const char *name);
