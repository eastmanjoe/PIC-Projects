//
// Hello Embedded World
//
// LDJ 10/24/05	my first PIC24 program with the MPLAB C30 compiler
//

#include <p24fj128ga010.h>

main()
{
	TRISB = 	0;		// all PORTA as output
	AD1PCFG = 0xffff;	// all PORTB as digital
	PORTB = 	0xff;	
}
