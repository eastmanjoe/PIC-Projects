/*
** It's an analog world
** Converting the analog signal from a TC1047 Temperature Sensor
*/

#include <p24fj128ga010.h>

#define POT     5       // 10k potentiometer connected to AN5 input
#define TSENS   4       // TC1047 Temperature sensor with voltage output
#define AINPUTS 0xffcf  // Analog inputs for Explorer16 POT and TSENS

// initialize the ADC for single conversion, select Analog input pins
void initADC( int amask) 
{
    AD1PCFG = amask;    // select analog input pins
    AD1CON1 = 0x00E0;   // auto convert after end of sampling 
//    AD1CON1 = 0x0004;   // auto sample after conversion
    AD1CSSL = 0;        // no scanning required 
    AD1CON3 = 0x1F02;   // max sample time = 31Tad, Tad = 3 x Tcy >75ns
    AD1CON2 = 0;        // use MUXA, AVss and AVdd are used as Vref+/-
    AD1CON1bits.ADON = 1; // turn on the ADC
} //initADC


int readADC( int ch)
{
    AD1CHS  = ch;               // select analog input channel
    AD1CON1bits.SAMP = 1;       // start sampling, automatic conversion will follow
    while (!AD1CON1bits.DONE);  // wait to complete the conversion
    return ADC1BUF0;            // read the conversion result
} // readADC


main ()
{
    int a, i, j, k;
    
    // initializations
    initADC( AINPUTS);  // initialize the ADC for the Explorer16 analog inputs
    TRISA = 0xff00;     // select the PORTA pins as outputs to drive the LEDs
	T1CON =   0x8030;   // TMR1 on, prescale 1:256 Tclk/2

    a = 0;
    for ( j= 16; j >0; j--)
         a += readADC( TSENS);  // read the temperature
    i = a >> 4;
    // this will give the central bar reference
    
    // main loop
    while( 1)
    {   
        
        a = 0;
        for ( j= 1; j >0; j--)
        {
			TMR1 = 0;
			while ( TMR1 < 3900);  // 16 x 3900 x 256 x Tcy ~= 1sec
            a += readADC( TSENS);  // read the temperature
        }
        //a >>= 4;                   // averaged over 16 readings
    
        // compare with the initial reading and move the bar 1 pos. per C
        a = 3 + (a - i);
        // keep the result in the value range 0..7, keep the bar visible
        if ( a > 7) 
            a = 7;
        if ( a < 0)
            a = 0;

        // turn on the corresponding LED
        PORTA = ( 0x80 >> a);

//        PORTA = readADC( TSENS)>>2;
    } // main loop
} // main
