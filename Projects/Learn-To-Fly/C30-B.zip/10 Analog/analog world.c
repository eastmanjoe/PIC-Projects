/*
** It's an analog world
**
*/

#include <p24fj128ga010.h>

#define POT     5       // 10k potentiometer connected to AN5 input
#define TSENS   4       // TC1047 Temperature sensor with voltage output
#define AINPUTS 0xffcf  // Analog inputs for Explorer16 POT and TSENS

// initialize the ADC for single conversion, select Analog input pins
void initADC( int amask) 
{
    AD1PCFG = amask;    // select analog input pins
    AD1CON1 = 0x00E0;   // auto convert after end of sampling 
    AD1CSSL = 0;        // no scanning required 
    AD1CON3 = 0x1F02;   // max sample time = 31Tad, Tad = 2 x Tcy = 125ns >75ns
    AD1CON2 = 0;        // use MUXA, AVss and AVdd are used as Vref+/-
    AD1CON1bits.ADON = 1; // turn on the ADC
} //initADC


int readADC( int ch)
{
    AD1CHS  = ch;               // select analog input channel
    AD1CON1bits.SAMP = 1;       // start sampling, automatic conversion will follow
    while (!AD1CON1bits.DONE);   // wait to complete the conversion
    return ADC1BUF0;            // read the conversion result
} // readADC


main ()
{
    int a;
    
    // initializations
    initADC( AINPUTS);  // initialize the ADC for the Explorer16 analog inputs
    TRISA = 0xff00;     // select the PORTA pins as outputs to drive the LEDs
    
    // main loop
    while( 1)
    {   
        a = readADC( POT);  // select the POT input and convert 

        // reduce the 10-bit result to a 3 bit value (0..7)
        // (divide by 128 or shift right 7 times
        a >>= 7;
        
        // turn on only the corresponding LED
        // 0 -> leftmost LED.... 7-> rigtmost LED
        PORTA = (0x80 >> a);
        
    } // main loop
} // main
