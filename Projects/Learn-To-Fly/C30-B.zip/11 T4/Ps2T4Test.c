/* 
** PS2 KBD Test
**
** 
** LDJ 6/9/06  v1.0
*/

#include <p24fj128ga010.h>

#include "PS2T4.h"

main()
{
    TRISA = 0xff00;
    initKBD();			        // call the initialization routine

    while ( 1)
    {
        if ( KBDReady)		    // wait for the flag 
        {
            PORTA = KBDCode; 	// fetch the key code and publish on PORTA
            KBDReady = 0; 		// clear the flag 
        }
    } // main loop
} //main
