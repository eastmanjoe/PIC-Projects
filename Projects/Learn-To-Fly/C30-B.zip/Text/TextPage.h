/*
** TextPage.h
**
** Text Page Video Module
**
** LDJ rev 1.0 - 5/29/06
*/

#define ROWS    25      // rows of text
#define COLS    48      // columns of text


// Text Page array
extern unsigned char  VMap[ COLS * ROWS];            

// initializes the video output
void initVideo( void);

// stops the video output
void haltVideo();

// clears the video map 
void initScreen( void);

// cursor 
extern int cx, cy;

void putV( int a);

void putsV( unsigned char *s);

void pcr( void);


#define home()      { cx=0; cy=0;}
#define clrscr()    { initScreen(); home();}
#define AT( x, y)   { cx = (x); cy = (y);}

    
