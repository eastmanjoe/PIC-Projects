/*
** TextPage.c
**
** Text Page video module
**
** LDJ rev 1.0 - 6/2/06
*/

#include <p24fj128ga010.h>
#include "../Text/TextPage.h"
#include "../font/font.h"

// I/O definitions
#define SYNC    _LATG0  // output 
#define SDO     _RF8    // SPI1 SDO

// calculates the NTSC video parameters for the vertical state machine
#define V_NTSC   262    // total number of lines composing a frame
#define VRES   (ROWS*8) // desired vertical resolution (<242)
#define VSYNC_N  3      // V sync lines
// count the number of remaining black lines top+bottom
#define VBLANK_N    (V_NTSC -VRES - VSYNC_N)  

#define PREEQ_N   VBLANK_N /2          // pre equalization + bottom blank lines
#define POSTEQ_N  VBLANK_N - PREEQ_N   // post equalization + top blank lines

// definition of the vertical sync state machine
#define SV_PREEQ    0
#define SV_SYNC     1
#define SV_POSTEQ   2
#define SV_LINE     3

// calculates the NTSC video parameters for the horizontal state machine
#define H_NTSC  1018    // total number of Tcy in a line (63.5us)
#define HRES   (COLS*8) // desired horizontal resolution (divisible by 16)
#define HSYNC_T  72     // Tcy in a horizontal synch pulse (4.7us)
#define BPORCH_T 90     // Tcy in a back porch (4.7us)
#define PIX_T    2      // Tcy in each pixel
#define LINE_T   HRES * PIX_T       // Tcy in each horizontal image line

// Text Page array
unsigned char  VMap[ COLS * ROWS];            
unsigned char *VPtr, *LPtr;

// reordered Font
unsigned char RFont[F_SIZE*8];
unsigned char *FPtr;

volatile int HCount, VCount, RCount, VState, HState; 

// next state table
int VS[4] = { SV_SYNC, SV_POSTEQ, SV_LINE, SV_PREEQ};
// next counter table
int VC[4] = { VSYNC_N,  POSTEQ_N,    VRES,  PREEQ_N};

void _ISRFAST _T3Interrupt( void)
{
_RA0=1;
    // Start a Synch pulse
    SYNC = 0;

    // decrement the vertical counter
    VCount--;
    
    // vertical state machine
    switch ( VState) {
        case SV_PREEQ:
           // horizontal sync pulse
            OC3R = HSYNC_T;
            OC3CON = 0x0009;    // single event 
            break;
            
        case SV_SYNC:
            // vertical sync pulse
            OC3R = H_NTSC - HSYNC_T;
            OC3CON = 0x0009;    // single event 
            break;
            
        case SV_POSTEQ:
            // horizontal sync pulse
            OC3R = HSYNC_T;
            OC3CON = 0x0009;    // single event 
            // on the last posteq prepare for the new frame
            if ( VCount == 0)
            {   
                LPtr = VMap;
                RCount = 0;
            }
            break;
            
        default:            
        case SV_LINE:
            // horizontal sync pulse
            OC3R = HSYNC_T;
            OC3CON = 0x0009;    // single event 

            // activate OC4 for the SPI loading
            OC4R = HSYNC_T + BPORCH_T;
            OC4CON = 0x0009;    // single event 
            HCount = 3;         // reload counter

            // prepare the font pointer
            FPtr = &RFont[ RCount * F_SIZE];
            // prepare the line pointer
            VPtr = LPtr;
                                               
            // Advance the RCount
            if ( ++RCount == 8)
            { 
                RCount = 0;
                LPtr += COLS;
            }
    } //switch

    // advance the state machine
    if ( VCount == 0)
    {
        VCount = VC[ VState];
        VState = VS[ VState];
     }

    // clear the interrupt flag
    _T3IF = 0;
_RA0=0;

} // T3Interrupt


void _ISRFAST _OC3Interrupt( void)
{
_RA0=1;
    SYNC = 1;   // bring the output up to the black level
    _OC3IF = 0; // clear the interrupt flag
_RA0=0;

} // OC3Interrupt


#define DECODE( sfr)\
    asm volatile( "mov.b [w1++], w0" );     \
    asm volatile( "ze w0, w0");             \     
    asm volatile( "mov.b [w2+w0], w3");     \      
    asm volatile( "sl w3,#8,w3" );          \     
    asm volatile( "mov.b [w1++], w0" );     \     
    asm volatile( "ze w0, w0");             \
    asm volatile( "mov.b [w2+w0], w0");     \     
    asm volatile( "ze w0, w0");             \
    asm volatile( "add w0, w3, w0");        \     
    asm volatile( "mov w0, %0" : "=U"( (sfr)));  


void _ISRFAST _OC4Interrupt( void) 
{    
_RA0=1;

    // prepare pointers
    __asm__( "mov %0, w2" ::"U" (FPtr) );   // w2 = FPtr
    __asm__( "mov %0, w1" ::"U" (VPtr));    // w1 = VPtr

    // inline text to font translation * 8 words
    DECODE( SPI1BUF); 
    DECODE( SPI1BUF); 
    DECODE( SPI1BUF); 
    DECODE( SPI1BUF); 
    DECODE( SPI1BUF); 
    DECODE( SPI1BUF); 
    DECODE( SPI1BUF); 
    DECODE( SPI1BUF); 
    __asm__( "mov w1, %0" :"=U" (VPtr));    // update VPtr
                            
    if ( --HCount > 0)
   	{   // activate again in time for the next SPI load
            OC4R += ( PIX_T * 8 * 16); 
            OC4CON = 0x0009;    // single event                 
	}
	        
	// clear the interrupt flag
	_OC4IF = 0;
_RA0=0;

} // OC4Interrupt


void initVideo( void)
{
    int i, j;
    const char *p;
    char *r = RFont;
    
    TRISA = 0xfffe;

    // prepare a reversed font table
    for (i=0; i<8; i++)
    {
        p = Font8x8 + i;
        for (j=0; j<F_SIZE; j++)
        {
            *r++ = *p;
            p+=8;
        } // for j
    }  // for i   
         
    // set the priority levels
	_T3IP = 4; 		// this is the default value anyway
	_OC3IP = 4;
    _OC4IP = 4;

	TMR3 = 0;		// clear the timer
	PR3 = H_NTSC;	// set the period register to NTSC line 
	
	// 2.1 configure Timer3 modules
	T3CON = 0x8000;	// enabled, prescaler 1:1, internal clock 	
	
	// 2.2 init Timer3/OC3/OC4 Interrupts, clear the flag
	_OC3IF = 0;	_OC3IE = 1;
    _OC4IF = 0; _OC4IE = 1;
    _T3IF = 0;  _T3IE = 1;
    	
	// 2.3 init the processor priority level
	_IP = 0;	// this is the default value anyway

    // init the SPI1 
    SPI1CON1 = 0x043B;      // Master, 16 bit, disable SCK, disable SS, prescaler 1:3
    SPI1CON2 = 0x0001;      // Enhanced mode, 8x FIFO
    SPI1STAT = 0x8000;      // enable SPI port
    
    // init PORTF for the Sync
    _TRISG0 = 0;            // output the SYNC pin
    	
	// init the vertical sync state machine
	VState = SV_PREEQ;
    VCount = PREEQ_N;
    
} // initVideo


void haltVideo()
{
    T3CONbits.TON = 0;   // turn off the vertical state machine
} //haltVideo


void initScreen( void)
{
    int i, j;
    char *v;
    
    v = VMap;
    
    // clear the screen     
    for ( i=0; i < (ROWS); i++)
        for ( j=0; j < (COLS); j++)
           *v++ = 0;
} //initScreen


int cx, cy;

void putcV( int a)
{    
    // check if char in font range
    a -= F_OFFS;
    if ( a < 0)         a = 0;
    if ( a >= F_SIZE)   a = F_SIZE-1; 
     
    // check page boundaries 
    if ( cx >= COLS)        // wrap around x
    {
        cx = 0;
        cy++;   
    } 
    cy %= ROWS;             // wrap around y
        
    // find first row in the video map
    VMap[ cy * COLS + cx] = a;
        
    // increment cursor position
    cx++;
} // putcV


void putsV( unsigned char *s)
{
    while (*s)
        putcV( *s++);
} // putsV


void pcr( void)
{
    cx = 0; 
    cy++;
    cy %= ROWS;
} // pcr
