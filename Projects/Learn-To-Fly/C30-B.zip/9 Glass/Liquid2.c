/*
**
** Playing with an LCD display
*/

#include <p24fj128ga010.h>

#define LCDDATA 1
#define LCDCMD  0


void LCDinit( void)
{
    // PMP intialization 
    PMCON = 0x83BF;         // Enable the PMP, long waits
    PMMODE = 0x3FF;         // Master Mode 1
	PMPEN = 0x0001;         // PMA0 enabled
    PMADDR = LCDCMD;        // command register
    
    // init TMR1
    T1CON = 0x8030;             // Fosc/2, prescaled 1:256, 16us/tick

    // wait for >30ms
    TMR1 = 0; while( TMR1<2000);// 2000 x 16us = 32ms   
    
    //initiate the HD44780 display 8-bit init sequence
    PMDIN1 = 0b00111000;        // 8-bit interface, 2 lines, 5x7
    TMR1 = 0; while( TMR1<3);   // 3 x 16us = 48us   
    
    PMDIN1 = 0b00001100;        // display ON, cursor off, blink off
    TMR1 = 0; while( TMR1<3);   // 3 x 16us = 48us   
    
    PMDIN1 = 0b00000001;        // clear display
    TMR1 = 0; while( TMR1<100); // 100 x 16us = 1.6ms   
    
    PMDIN1 = 0b00000110;        // increment cursor, no shift
    TMR1 = 0; while( TMR1<100); // 100 x 16us = 1.6ms   
} // LCDinit


char LCDread( int addr)
{
    int dummy;
    while( PMMODEbits.BUSY);    // wait for PMP to be available
    PMADDR = addr;              // select the command address
    dummy = PMDIN1;            // initiate a read cycle, dummy read
    while( PMMODEbits.BUSY);    // wait for PMP to be available
    return( PMDIN1);            // read the status register
    
} // LCDread

#define LCDbusy() LCDread( LCDCMD) & 0x80
#define LCDaddr() LCDread( LCDCMD) & 0x7F
#define getLCD()  LCDread( LCDDATA)

    
void LCDcmd( char c)
{
    while( LCDbusy());
    while( PMMODEbits.BUSY);    // wait for PMP to be available
    PMADDR = LCDCMD;
    PMDIN1 = c;
} // LCDcmd
    

void putLCD( char d)
{
    while( LCDbusy());
    while( PMMODEbits.BUSY);    // wait for PMP to be available
    PMADDR = LCDDATA;
    PMDIN1 = d;
} // putLCD


void putsLCD( char *s)
{
    while( *s) putLCD( *s++);
} //putsLCD


#define LCDhome()    LCDcmd( 2)    
#define LCDclr()     LCDcmd( 1)
#define LCDsetG( a) LCDcmd( a | 0x40)
#define LCDsetC( a) LCDcmd( a | 0x80)


#define TFLY 9000       // 9000 x 16us = 144ms
#define DELAY() TMR1=0; while( TMR1<TFLY)

int cg[] = { 0x0041, 0x0187, 0x3fff, 0x5563, 0xffff, 0x0380, 0x01c0};
char sg[24];

void Sprite( int shift)
{    // shift is a value 0..14
    long l;
    int i; 
    
    for( i=0; i<7; i++)
    {
         l = ((long)cg[i]) << shift;
         sg[i] = l >> 20;
         sg[i+8] = l >> 10;
         sg[i+16] = l >> 2;
    }
    sg[7] = 0;
    sg[15] = 0;
    sg[23]= 0;
    
    // generate three new characters from the sprite sg
    LCDsetG(0);
    for( i=0; i<24; i++)
        putLCD( sg[ i]);
}
             
main( void)
{
    int i, j;
        
    // initializations
    LCDinit();
    
    // put a title on the first line    
    putsLCD( "Flying the PIC24");

    
    // main loop
    while( 1)
    {
        // erase the tail
        
        // fly fly
        for( i=13; i>=0; i--)
        {
            for( j = 0; j<8; j++)
            {
                Sprite( j);
                LCDsetC(0x40+i);      // set the cursor
                putLCD(1); putLCD(0); putLCD(4);
                DELAY();
            } // for j
        } // for i
        
        // the tip disappears, only the tail is visible
    } // main loop
} // main
