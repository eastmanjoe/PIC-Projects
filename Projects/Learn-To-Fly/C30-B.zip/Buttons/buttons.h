/*
**
**	Buttons read and debounce
*/

int getKEY();

int readKEY();
