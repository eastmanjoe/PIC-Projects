/*
** Text on Graphic Page
**
** LDJ rev 1.0 - 06/06/06
*/

extern int cx, cy;

void putcV( int a);

void putsV( unsigned char *s);


#define Home()      { cx=0; cy=0;}
#define Clrscr()    { clearScreen(); Home();}
#define AT( x, y)   { cx = (x); cy = (y);}
    
