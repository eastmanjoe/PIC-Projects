//
// NTSC Video Text on Graphic Page
//

#include <p24fj128ga010.h>
#include "../font/font.h"
#include "../graphic/graphic.h"

int cx, cy;


void putcV( int a)
{
    int i, *p;
    const char *pf;
    
    // 1. check if char in range
    a -= F_OFFS;
    if ( a < 0)         a = 0;
    if ( a >= F_SIZE)   a = F_SIZE-1; 
     
    // 2. check page boundaries 
    if ( cx >= HRES/8)          // wrap around x
    {
        cx = 0;
        cy++;   
    } 
    if ( cy >= VRES/8)          // wrap around y (or scroll?)
        cy = 0;
        
    // 3. set pointer to word in the video map
    p = &VMap[ cy * 8 * HRES/16 + cx/2];
    // set pointer to first row of the character in the font array
    pf = &Font8x8[ a << 3];
    
    // 4. copy one by one each line of the character on the screen
    for ( i=0; i<8; i++)
    {
        if ( cx & 1)
        {
            *p &= 0xff00;
            *p |= *pf++;
        } 
        else 
        {
            *p &= 0xff;
            *p |= (*pf++)<<8;
        }   
        // point to next row
        p += HRES/16; 
    } // for
    
    // increment cursor position
    cx++;
} // putcV

void putsV( unsigned char *s)
{
    while (*s)
        putcV( *s++);
} // putsV

    
