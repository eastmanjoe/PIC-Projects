/* 
** Delay routines using TMR1
**
*/
#include "p24fj128ga010.h"

void Delayms( unsigned t)
{
    T1CON = 0x8000;     // enable tmr1, Tcy, 1:1
    while (t--)
    {
        TMR1 = 0;
        while (TMR1<16000);
    }
} // Delayms
