/*
** Delay routines using TMR1
**
*/

void Delayms( unsigned);
