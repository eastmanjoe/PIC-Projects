//
// Numbers
//
// LDJ 4/11/06
//

#include <p24fj128ga010.h>
char 		h;
int 		i1, i2, i3;
long  		l1, l2, l3;
long long 	ll1, ll2, ll3;
float 		f1,f2, f3;
long double d1, d2, d3;

main ()
{
	
	i1 = 1234;	// testing integers (16-bit)
	i2 = 5678;	
	i3= i1 * i2;	

	l1 = 1234L;	// testing long integers (32-bit)
	l2 = 5678L;	
	l3= l1 * l2;	

	ll1 = 1234LL;	// testing long long integers (64-bit)
	ll2 = 5678LL;	
	ll3= ll1 * ll2;	

	f1 = 12.34;	// testing single precision floating point
	f2 = 56.78;	
	f3= f1 * f2;	

	d1 = 12.34L;	// testing double precision floating point
	d2 = 56.78L;	
	d3= d1 * d2;	


} // main
