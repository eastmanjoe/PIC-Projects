//
// Complex Numbers
//
// LDJ 4/15/06
//

#include <p24fj128ga010ps.h>

__complex__ int z, k;
int r, i;

main ()
{
		k = 2 + 3j;
		__real__ z = 1;
		__imag__ z = 1;
		k *= z;
}
