/*
** Audio PWM demo 
**
** LDJ 7/22/06 v1.1
*/

#include <p24fj128ga010.h>

#include "Audio PWM.h"

#define _FAR __attribute__(( far))

// global definitions
unsigned Offset;                    // 50% duty cycle value
char  _FAR  ABuffer[ 2][ B_SIZE];   // double data buffer
int     CurBuf;                     // index of buffer in use
volatile int AEmptyFlag;            // flag a buffer needs to be filled

// internal variables
int Stereo;                         // flag stereo play back
int Fix;                            // sign fix for 16-bit samples
int Skip;                           // skip factor to reduce sample/rate
int Size;                           // sample size (8 or 16-bit)

// local definitions
unsigned char *BPtr;                // pointer inside active buffer
int BCount;                         // count bytes used 

void initAudio( long bitrate, int skip, int size, int stereo, int fix, int pos)
{
    // 1. init pointers 
    CurBuf = 0;                 // start with buffer0 active first
    BPtr = ABuffer[ CurBuf]+pos;
    BCount = (B_SIZE-pos)/size; // number of samples to be played
    AEmptyFlag = 0;
    Skip = skip;
    Fix = fix;                  
    Stereo = stereo;
    Size = size;

    // 2. init the timebase
    T3CON = 0x8000;         // enable TMR3, prescale 1:1, internal clock
    PR3 = FCY / bitrate;    // set the period for the given bitrate
    Offset = PR3/2;         
    _T3IF = 0;              // clear interrupt flag
    _T3IE = 1;              // enable TMR3 interrupt

    // 3. set the initial duty cycles
    OC1R = OC1RS = Offset;  // left
    OC2R = OC2RS = Offset;  // right

    // 4. activate the PWM modules 
    OC1CON = 0x000E;        // CH1 and CH2 in PWM mode, TMR3 based
    OC2CON = 0x000E;

} // initAudio


void haltAudio( void)
{
//    T3CON = 0;              // disable TMR3
   _T3IE = 0;
} // halt audio


void _ISRFAST _T3Interrupt( void)
{
    // 1. load the new samples for the next cycle
    OC1RS = 30+(*BPtr ^ Fix); 
    if ( Stereo)
        OC2RS =30 + (*(BPtr + Size) ^ Fix);
    else    // mono
        OC2RS = OC1RS;

    // 2. skip samples to reduce the bitrate
    BPtr += Skip;

    // 3. check if buffer emptied
    if ( --BCount == 0)
    {
        // 3.1 swap buffers
        CurBuf = 1- CurBuf;
        BPtr = &ABuffer[ CurBuf][Size-1];
        
        // 3.2 restart counter
        BCount = B_SIZE/Skip;

        // 3.3 flag a new buffer needs to be filled
        AEmptyFlag = 1;
    }

    // 4. clear interrupt flag and exit
    _T3IF = 0;
} // T3 Interrupt

