/*
** NTSC Video Text Page Test
**
*/ LDJ rev 1.0 - 5/30/06

#include <p24fj128ga010.h>
#include "../graphic/graphic.h"
#include "../textg/TextOnGPage.h"
#include <stdio.h>

#define PI 3.141592654

main()
{
    int i, j, k;
    
    // initializations
    initVideo();    // start the state machines
    
    Clrscr();
    
	while( 1)
	{    
    	AT( 0, 0);
        putsV( "FLYING THE PIC24!");
        AT( 0, 2);
        printf( "PI = %f", PI);
        
        // wait for a button to be pressed
        while (1) 
        {  // wait for a key pressed          
            if ( !_RD6)
            {  // first quadrant
                break;
            }
            if ( !_RD7)
            { // second quadrant
                break;
            }
            if ( !_RA7)
            {  // third quadrant
                break;
            }
            if ( !_RD13)
            { // fourth quadrant
                break;
            }        
        } // wait for a key
        
	} // main loop

} // main
