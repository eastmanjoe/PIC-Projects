/*
**
** Mandelbrot Set graphic demo
**
** LDJ rev 2.0 - 6/10/06
*/

#include <p24fj128ga010.h>
#include "../graphic/graphic.h"

#define SIZE  VRES
#define MAXIT 64

void mandelbrot( float xx0, float yy0, float w)
{
    float x, y, d, x0, y0, x2, y2;
    int i, j, k;

    // calculate increments
    d = w/SIZE;
    
    // repeat on each screen pixel
    y0 = yy0;
    for (i=0; i<SIZE; i++)
    {
        x0 = xx0;
        for (j=0; j<SIZE; j++)
        {        
            // initialization
              x = x0;
              y = y0;         
              k = 0;
             
             // core iteration
              do {
                x2 = x*x;
                y2 = y*y;
                y = 2*x*y + y0;
                x = x2 - y2 + x0;                        
                k++;
              } while ( (x2 + y2 < 4)  && ( k < MAXIT)); 
            
            // check if the point belongs to the Mandelbrot set
            if ( k & 2) plot( j, i);
            //if ( k == MAXIT) plot( j, i);

            // compute next point x0
            x0 += d;             
         } // for j
         PORTA = i;
         // compute next y0
         y0 += d; 
     } // for i
 } // mandelbrot
 
 main()
{
    float x, y, w;
    
    // initializations
	TRISA = 0xff80;	// set PORTA lsb as output for debugging
    initVideo();    // start the state machines
    
    // intial coordinates lower left corner of the grid 
    x = -2.0;
    y = -2.0;
    // initial grid size
    w = 4.0;
    
	while( 1)
	{    
        clearScreen();          // clear the screen
        mandelbrot( x, y, w);   // draw new image
       

        // wait for a button to be pressed
        while (1) 
        {  // wait for a key pressed          
            if ( !_RD6)
            {  // first quadrant
                w/= 2;
                y += w;
                break;
            }
            if ( !_RD7)
            { // second quadrant
                w/= 2;
                y += w;
                x += w;
                break;
            }
            if ( !_RA7)
            {  // third quadrant
                w/= 2;
                x += w;
                break;
            }
            if ( !_RD13)
            { // fourth quadrant
                w/= 2;
                break;
            }        
        } // wait for a key
        
	} // main loop

} // main
