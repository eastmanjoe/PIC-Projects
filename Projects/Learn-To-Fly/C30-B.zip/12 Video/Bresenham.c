//
// Bresenham.c
//
// Bresenham algorithm example
//

#include <p24fj128ga010.h>
#include <stdlib.h>

#include "../graphic/graphic.h"

main()
{
    int i;

    // initializations
    initVideo();    // start the state machines
    srand( 12);
    
    // main loop
	while( 1)
	{   
        clearScreen();
        line( 0, 0, 0, VRES-1);
        line( 0, VRES-1, HRES-1, VRES-1);
        line( HRES-1, VRES-1, HRES-1, 0);
        line( 0, 0, HRES-1, 0);
    
        for( i = 0; i<100; i++) 	
            line( rand()%HRES, rand()%VRES, rand()%HRES, rand()%VRES);
        while( 1)
        {        
            if ( !_RD6)
                break;
        } // wait for a key

	} // main loop

} // main
