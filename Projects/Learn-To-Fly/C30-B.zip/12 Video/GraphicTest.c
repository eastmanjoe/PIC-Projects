//
// Graphic Test.c
//
// testing the basic graphic module
//

#include <p24fj128ga010.h>

#include "../graphic/graphic.h"


main()
{
    // initializations
	TRISA = 0xff80;	// set PORTA lsb as output for debugging
    clearScreen();  // init the video map
    initVideo();    // start the video state machine

    // main loop    
	while( 1)
	{   
   
	} // main loop

} // main
