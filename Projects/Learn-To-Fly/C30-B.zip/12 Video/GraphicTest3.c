//
// Graphic Test3.c
//
// testing the basic graphic module
//

#include <p24fj128ga010.h>

#include "../graphic/graphic.h"


void Plot( unsigned x, unsigned y) 
{
     if ((x<HRES) && (y<VRES) )
        VMap[ ((VRES-1-y)<<4) + (x>>4)] |= (0x8000 >> (x & 0xf));
} // plot


main()
{
    int i;

    // initializations
    clearScreen();  // init the video map
    initVideo();    // start the video state machine

    srand(13);  // initialize the pseudo random number generator
    
    for( i=0; i<1000; i++)
    {
        Plot( rand()%HRES, rand()%VRES);  
    }

    // main loop    
	while( 1)
	{   
   
	} // main loop

} // main
