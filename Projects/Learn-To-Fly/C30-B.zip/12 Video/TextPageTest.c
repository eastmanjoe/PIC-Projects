/*
** Text Page Test
**
*/

#include <p24fj128ga010.h>
#include "../graphic/graphic.h"
#include "../textg/TextOnGPage.h"

main( void)
{
    int i;
    
    // initializations
    initVideo();    // start the state machines
    
    Clrscr();
    
    AT( 0, 0);
    putsV( "FLYING THE PIC24!");
        
    AT( 0, 2);
    for( i=32; i<128; i++)
	    putcV( i);

    while (1);

} // main
