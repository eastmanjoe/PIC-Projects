/*
**  The Matrix2
**
**  LDJ v2.0 5/30/06
*/
#include <p24fj128ga010.h>

#include "../TextG/TextOnGPage.h"

#define COL     40
#define ROW     23
#define DELAY 12000

#define pcr() {cx = 0; cy++;}
    
main()
{
    int v[40];  // vector containing lengh of each string
    int i,j,k;
    
    // 1. initializations
    T1CON = 0x8030; // TMR1 on, prescale 256, Tcy/2

    initVideo();
    Clrscr();       // clear the screen
    srand( 12);     // start the random number sequence
    
    // 2. init each column lenght
    for( j =0; j<COL; j++)
            v[j] = rand()%ROW;
    
    // 3. main loop
    while( 1)
    {
        Home();
        
        // 3.1 refresh the screen with random columns
        for( i=0; i<ROW; i++)
        {
            
            // refresh one row at a time
            for( j=0; j<COL; j++)
            {
                // print a random character down to each column lenght
                if ( i < v[j])
                    putcV( 'A' + (rand()%32));
                else 
                    putcV(' ');
//                putcV( ' ');
            } // for j
            pcr();
            
        } // for i

            // 3.1.1 delay to slow down the screen update
            TMR1 =0;   
            while( TMR1<DELAY);
        // 3.2 randomly increase or reduce each column lenght
        for( j=0; j<COL; j++)
        {
            switch ( rand()%3)
            {
                case 0: // increase length
                        v[j]++;
                        if (v[j]>ROW)
                            v[j]=ROW;
                        break;
                        
                case 1: // decrease length
                        v[j]--;
                        if (v[j]<1)
                            v[j]=1;
                        break;
                        
                default:// unchanged 
                        break;
             } // switch
        } // for

    } // main loop
} // main
