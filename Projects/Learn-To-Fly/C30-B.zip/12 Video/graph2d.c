/*
** Plotting a 2D function graph
** 
**
** v1.00 LDJ 7/2/06
*/

#include <p24fj128ga010.h>
#include <math.h>

#include "../graphic/graphic.h"

#define X0      10
#define Y0      10
#define PI      3.141592654f
#define NODES   20
#define SIDE    10

typedef struct {
        int x;
        int y;
    } point;

point edge[NODES], prev;

main( void)
{
    int i, j, x, y, z;
    float xf, yf, zf, sf;
    int px, py;

    // initializations
    clearScreen();
    initVideo();    

    // draw the x, y and z axes crossing in (X0,Y0)
    line( X0, 10, X0, VRES-50);         // z axis
    line( X0-5, Y0, HRES-10, Y0);       // x axis 
    line( X0-2, Y0-2, X0+120, Y0+120);  // y axis

    // init the array of previous egde points
    for( j = 0; j<NODES; j++)
    {
        edge[j].x = X0+ j*SIDE/2;
        edge[j].y = Y0+ j*SIDE/2;
    }

    // plot the graph of the function for 
    for( i=0; i<NODES; i++)
    {
        // transform the x coordinate range to 0..200 offset 100
        x = i * SIDE;
        xf = (6 * PI / 200) * (float)(x-100);
        prev.y = Y0;
        prev.x = X0 + x;

        for ( j=0; j<NODES; j++)
        { 
            // transform the y coordinate range to 0..200 offset 100
            y = j * SIDE;
            yf = (6 * PI / 200) * (float)(y-100);
            
            // compute the function
            sf = sqrt( xf * xf + yf * yf);
            zf = 1/(1+ sf) * cos( sf );
            
            // scale the output
            z = zf * 75;
            
            // apply isometric perspective and offset
            px = X0 + x + y/2;
            py = Y0 + z + y/2; 
            
            // plot the point
            plot( px, py);
        
            // draw connecting lines to visualize the grid
            line( px, py, prev.x, prev.y);  // connect to prev point on same x
            line( px, py, edge[j].x, edge[j].y);

            // update the previous points
            prev.x = px;
            prev.y = py;
            edge[j].x = px;
            edge[j].y = py;
        } // for j
    } // for i

    // main loop
    while( 1);

} // main
