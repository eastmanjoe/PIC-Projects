//
// Graphic Test2.c
//
// testing the basic graphic module
//

#include <p24fj128ga010.h>

#include "../graphic/graphic.h"

main()
{
    int x, y;

    // initializations
    clearScreen();  // init the video map
    initVideo();    // start the video state machine

    // fill the video memory map with a pattern
    for( y=0; y<VRES; y++)
        for (x=0; x<HRES/16; x++)
            VMap[y*16 + x]= y;  
    

    // main loop    
	while( 1)
	{   
   
	} // main loop

} // main
