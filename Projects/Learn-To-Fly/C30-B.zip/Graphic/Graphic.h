/*
**  NTSC Video 
**  Graphic library
**
**
*/

#define VRES     192    // desired vertical resolution
#define HRES     256    // desired horizontal resolution (pixel)

void initVideo( void);

void haltVideo( void);

void clearScreen( void);

void plot( unsigned x, unsigned y); 

void line( int x0, int y0, int x1, int y1);

void synchV( void);

extern int VMap[HRES/16*VRES];
