/*
** NVM Library test
*/ 

#include <p24fj128ga010.h>

#include "NVM.h"


main()
{
	int data;

	// initialize the SPI2 port and CS to access the 25LC256
	InitNVM();
	
	// main loop
	while ( 1)
	{
		// read current content of memory location
		data = iReadNVM( 0x1234);
	
		// increment current value
		Nop();			// <-set brkpt here
		data++;				
		
		// write back the new value
		iWriteNVM( 0x1234, data);
		//address++;
		
	} // main loop
} //main
