/*
**
** LCD.h
**
** 7/30/06 LDJ v1.0
*/

#include <p24fj128ga010.h>

#define LCDDATA 1
#define LCDCMD  0
#define PMDATA  PMDIN1

void initLCD( void);
char readLCD( int addr);

#define busyLCD() readLCD( LCDCMD) & 0x80
#define addrLCD() readLCD( LCDCMD) & 0x7F
#define getLCD()  readLCD( LCDDATA)


void writeLCD( int addr, char c);    

#define putLCD( d)  writeLCD( LCDDATA, (d))
#define cmdLCD( c)  writeLCD( LCDCMD, (c))

#define homeLCD()   writeLCD( LCDCMD, 2)    
#define clrLCD()    writeLCD( LCDCMD, 1)
#define setLCDG( a) writeLCD( LCDCMD, (a & 0x3F) | 0x40)
#define setLCDC( a) writeLCD( LCDCMD, (a & 0x7F) | 0x80)

void putsLCD( char *s);



