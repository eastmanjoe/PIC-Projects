/*
** Test SD card interface
**
** 7/7/06 LDJ v. 2.0
*/

#include <p24fj128ga010.h>

#include "stdlib.h"
#include "sdmmc.h"
#include "fileio.h"

unsigned char buffer[512];

main( void)
{
    int i, r; 
    FILE *fp;
    char data[512];

    TRISA = 0xff00;
    initSD();

    while ( !detectSD());       // wait for card to be inserted

    if ( mount()== NULL)
        PORTA = FError + 0x80;
    else
    {
        PORTA = 0xFF;
        for( i=1; i<100; i++)
        {
            fp = fopen( "GRAPH2D.TXT", "r");
            if ( fp == NULL)    
                break;
            else
            {   // read entire file content
                while( (r = fread( data, 512, fp) == 512));
                Nop(); Nop();
                // close file
                fclose( fp);
            } // fopen
        } // for
        PORTA = 0;
    } // mounted

    while( 1)
    {
    } // main loop

} // main
