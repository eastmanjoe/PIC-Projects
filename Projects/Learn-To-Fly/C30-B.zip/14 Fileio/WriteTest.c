/*
**	WriteTest.c
**
*/

#include <p24fj128ga010.h>

#include "../delay/delay.h"
#include "../8 comm/conu2.h"
#include "../13 sdmmc/SDMMC.h"
#include "fileio.h"

#define B_SIZE   1024

char data[B_SIZE];


int main( void)
{
    MFILE *fs, *fd;
    unsigned r;

    //initializations
    initU2();           //115,200 baud 8,n,1
 
    putsU2( "init");
    while( !detectSD());    // assumes SDCD pin is by default an input
    Delayms( 100);          // wait for card to power up
        
    if ( mount())
    {
        putsU2("mount");
        if ( (fs = fopenM( "source.txt", "r")))
        {
            putsU2("source file opened for reading");
            if ( (fd = fopenM( "dest3.txt", "w")))
            {
                putsU2("destination file opened for writing");
                do{
                    r = freadM( data, B_SIZE, fs);

                    r = fwriteM( data, r, fd);

                    putU2('.');

                } while( r==B_SIZE);

                fcloseM( fd);
                putsU2("destination file closed");
            }
            else 
                putsU2("could not open the destination file");

            fcloseM( fs);
            putsU2("source file closed");
        } 
        else
            putsU2("could not open the source file");

        unmount();
        putsU2("unmount");

    }
    else 
        putsU2("mount failed");
    
    // main loop
    while( 1);
} // main
